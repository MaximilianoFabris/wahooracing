# Final five-card artwork copy

Private owner-review draft. Exact artwork: exports/A43-01.png through A43-05.png.
The separate EDITORIAL_COPY_EXPLORATION.md preserves earlier alternatives and is not the final sequence.

1. Designed to be built.
   DEVELOPMENT CAD / CNC STUDY
   Turning internal passages into a material study.
   PARTIAL CAD STUDY · NOT MANUFACTURING-VALIDATED

2. INSIDE THE ENGINE
   The route comes first.
   Actual transfer-passage geometry guides the host.
   A42 PASSAGE CONTEXT · PRELIMINARY OPEN NECK

3. THE CNC CHALLENGE
   Could a removable cover create access?
   A candidate architecture. Assembly still unresolved.
   GRAPHICAL SEPARATION · REMOVAL PATH NOT VERIFIED

4. Every detail matters.
   The interface is part of the design.
   Sealing and register allocations are provisional.
   ACTUAL Y = 55 mm SECTION · NO SEAL DESIGN RELEASED

5. ENGINEERING IN PROGRESS
   NEXT: Assembly / Stock / Sealing
   Questions to resolve before machining.
   A step towards a buildable engine.
   Partial editable modules. No physical validation yet.
   DEVELOPMENT STUDY · COMPLETE ENGINE NOT MODELLED

All cards carry the Wahoo engine-development footer and sequential folios. Use CAPTION.txt and ALT_TEXT.json with these exact exports. No new queue number is assigned; keep the established order unchanged. Propose a lifestyle/rider publication next to provide an editorial break.
